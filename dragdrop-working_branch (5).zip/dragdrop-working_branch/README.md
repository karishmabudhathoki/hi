### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

You don’t have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

# common issues

... Error message "error:0308010C:digital envelope routines::unsupported"
https://stackoverflow.com/questions/69692842/error-message-error0308010cdigital-envelope-routinesunsupported

# alternatives to the makeStyles hook in Material-UI for defining styles

CSS in JS libraries: There are several CSS in JS libraries that allow you to define styles in your React components using JavaScript. Some popular options include styled-components, emotion, and linaria. These libraries provide a way to define styles in your components without having to use CSS files.

Inline styles: You can use inline styles to apply styles directly to your React components. This can be done using the style prop, which takes an object of style properties and values. Inline styles can be useful for applying simple styles or for quickly prototyping an app.

CSS modules: CSS modules allow you to import CSS files into your React components and apply styles using class names. This can be a good option if you prefer to keep your styles in separate CSS files and want to avoid the risk of global class name conflicts.

Global CSS: You can also use global CSS files to apply styles to your React app.
This can be done by linking to a CSS file in the head of your HTML file or by
using a tool like postcss to process your CSS. Global CSS can be useful if you
have a large app with many shared styles.

# few react best practices

Use functional components whenever possible: Functional components are simpler and easier to reason about than class-based components. They also perform better because they don't have the overhead of a class instance.

Use the React context API for managing global state: The React context API allows you to share state between components without the need for props drilling. This can make your code cleaner and more maintainable.

Use memoization to optimize performance: Memoization is a technique for improving the performance of functions by caching their results. You can use the React.useMemo hook to memoize expensive calculations in your components, which can improve the performance of your app.

Use the React DevTools profiler to identify performance bottlenecks: The React DevTools profiler is a powerful tool for identifying performance issues in your app. It allows you to record performance data as you interact with your app and visualize that data to identify areas where performance can be improved.

Use the react-testing-library for writing reliable tests: The react-testing-library is a popular library for writing tests for React components. It encourages you to write tests that focus on the behavior of your components, rather than their implementation details, which can make your tests more reliable and easier to maintain.

# example usage of post api service

// Example usage:

// Create a new resource
const newResource = await ApiService.create('resources', {
name: 'New Resource',
description: 'This is a new resource'
});

// Get a list of resources
const resources = await ApiService.getAll<Resource>('resources');

// Get a single resource by ID
const resource = await ApiService.getById<Resource>('resources', '123');

// Update an existing resource
const updatedResource = await ApiService.update<Resource>('resources', '123', {
name: 'Updated Resource',
description: 'This resource has been updated'
});

// Delete a resource
await ApiService.delete('resources', '123');

# context Api

The Context API in React is a way to pass data through the component tree without having to pass props down manually at every level. It can be useful in situations where you have some data that you want to be available to a deep part of the component tree, but don't want to pass it down through every intermediate level of the tree as props. Instead, you can use the Context API to create a context provider at the level where you want to make the data available, and then consume the data at any level of the tree below the provider using a Context consumer.

For example, consider a tree of components like this:
App
Page
Header
Content
Sidebar
Main
Footer

Suppose you have some data that you want to be available to the Sidebar and Main components, but don't want to pass it down as props through the Content, Page, and App components. Instead, you could use the Context API to create a context provider at the App level, and then consume the data in the Sidebar and Main components using a context consumer. This way, you can avoid having to pass the data down through all of the intermediate components as props.

It's important to note that the Context API should be used sparingly, as it can
make it more difficult to understand how data is being passed through the
component tree. In general, it's best to pass data down through the tree as
props whenever possible, and only use the Context API when it is truly
necessary.

## Tech Stack

- Language: [TypeScript](https://www.typescriptlang.org/)
- UI-Components: [Ant Design](https://ant.design/)
- Icons: [Ant Design Icons](https://ant.design/components/icon/)
- Drag & Drop: [react-beautiful-dnd](https://github.com/atlassian/react-beautiful-dnd)
- Styling: [styled-components](https://styled-components.com/)
- Linting: [ESLint](https://eslint.org/)
- Code Formatting: [Prettier](https://prettier.io/)
- Deployment: [GitHub Actions](https://github.com/features/actions)
- Hosting: [GitHub Pages](https://pages.github.com/)

### Features

🖋 Create, edit & delete tasks  
☝ Change task order and status by drag & drop  
💾 Tasks are persisted to localStorage  
🔃 Sync between tabs  
🚀 Automated deployments with GitHub Actions
