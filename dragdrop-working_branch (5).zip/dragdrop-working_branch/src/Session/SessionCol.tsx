import { Droppable, Draggable } from 'react-beautiful-dnd';
import SessionItemCard from './SessionItemCard';
import { useEffect, useState } from 'react';
import { CustomCheckbox, SessionButton, SessionColRoot } from './SessionStyles';
import { DroppableRoot } from './SessionStyles';
import { SessionColProps, SessionStatus } from '../misc/Types';
import { getStatusButton } from '../misc/Utils';
import BaseTooltip from '../shared/BaseTooltip';

function SessionCol({
  items,
  status,
  onClickAdd,
  search,
  setItemsByStatus,
}: SessionColProps) {


  const [value, setValue] = useState('');

  const onChange = (row: any) => {
    const name = row.target.name as SessionStatus;
    setItemsByStatus(name, row.target.checked);
  };

  //update this func
  const onSearch = (e: any) => {
    setValue(e.target.value);
    search( e.target.name,e.target.value);
  };

  useEffect(() => { }, [items]);

  return (
    <SessionColRoot
      title={`${status} (${items.length})`}
      extra={
        onClickAdd && (
          <>{items.length ?
            <> 
              {/* <input
        type="search"
        value={value}
        name={status}
        onChange={onSearch}
        className="input"
        placeholder="Filter"
      /> */}

             <BaseTooltip overlay='Select All'> <CustomCheckbox name={status}  onChange={onChange}> </CustomCheckbox>  </BaseTooltip>          
           <SessionButton
              colors = {(getStatusButton(status) as any).buttonColor } 
              onClick={onClickAdd}
            >
              {getStatusButton(status)?.text}
            </SessionButton>  </>
            : null}
          </>
        )
      }
    >
      <Droppable droppableId={status}>
        {(provided, snapshot) => (
          <DroppableRoot
            ref={provided.innerRef}
            {...provided.droppableProps}
            isDraggingOver={snapshot.isDraggingOver}
          >
            {items.map((item, index) => {
              return (
                <Draggable
                  key={item.roadmapId}
                  draggableId={item.roadmapId}
                  index={index}
                >
                  {(provided, snapshot) => (
                    <div
                      key={item.roadmapId}
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                    >
                      <SessionItemCard
                        item={item}
                        status={status}
                        isDragging={snapshot.isDragging}
                      />
                    </div>
                  )}
                </Draggable>
              );
            })}
            {provided.placeholder}
          </DroppableRoot>
        )}
      </Droppable>
    </SessionColRoot>
  );
}

export default SessionCol;
