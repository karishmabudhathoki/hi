import { Typography, Checkbox } from 'antd';

import BaseTooltip from '../shared/BaseTooltip';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { SessionItemCardProps } from '../misc/Types';
import { StyledCard, SessiontemCardTitle } from './SessionStyles';

function SessioinItemCard({
  item,
  status,
  isDragging,
}: SessionItemCardProps) {
  const navigate = useNavigate();
  const handleClick = (roadmapId: string) => {
    navigate(`/phase/${roadmapId}`);
  };

  const [isChecked, setIsChecked] = useState(false);

  const handleChange = (event: any) => {
    setIsChecked(event.target.checked);
    if(item && item.selected)
    item.selected = event && event.target && event.target.checked;
  };

  useEffect(() => {  
    setIsChecked(item.selected as any);
    
   }, [item]);

  return (
    <StyledCard
      $isDragging={isDragging}
      size="small"
      title={
        <BaseTooltip overlay={item.roadmapId}>
          <span>
            <SessiontemCardTitle
              onClick={() => handleClick(item.roadmapId)}
              level={5}
              ellipsis={{ rows: 2 }}
            >
              {item.roadmapName}
            </SessiontemCardTitle>
          </span>
        </BaseTooltip>
      }
      extra={<Checkbox checked={isChecked}
      onChange={handleChange}></Checkbox>}
    >
      <BaseTooltip >
        <Typography.Paragraph
          onClick={() => handleClick(item.roadmapId)}
          type="secondary"
          ellipsis={{ rows: 2 }}
        >
           {item.description}
        </Typography.Paragraph>
        <Typography.Paragraph
          onClick={() => handleClick(item.roadmapId)}
          type="secondary"
          ellipsis={{ rows: 1 }}
        >
            Version Id: {item.versionId}
      
        </Typography.Paragraph>
        <Typography.Paragraph
          onClick={() => handleClick(item.roadmapId)}
          type="secondary"
          ellipsis={{ rows: 2 }}
        >
       
          Verified By: {item.verifiedBy}
        </Typography.Paragraph>
      </BaseTooltip>
    </StyledCard>
  );
}

export default SessioinItemCard;
