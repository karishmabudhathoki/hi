/* eslint-disable @typescript-eslint/no-explicit-any */
import { DragDropContext, DragDropContextProps } from 'react-beautiful-dnd'
import { useEffect, useState } from 'react'
import produce from 'immer'
import SessionCol from './SessionCol'
import { useSyncedState } from '../shared/SharedHooks'
import { SessionRoot, SessionContent } from './SessionStyles'
import { Roadmap, SessionData, SessionStatus } from '../misc/Types'
import SearchBox from '../shared/SearchBox'
import { filterItemGlobally } from '../misc/Utils'
import { session } from '../misc/DataGen'

const defaultItems = {
  [SessionStatus.PENDING]: [],
  [SessionStatus.APPROVED]: [],
  [SessionStatus.REJECTED]: []
}

function SessionMain() {
  const [itemsByStatus, setItemsByStatus] = useSyncedState<SessionData>(
    'itemsByStatus',
    defaultItems
  )

  const [sessionItems, setSessionItems] = useState<SessionData>({} as any)

  useEffect( () => {
    //comment this out once done seeding data
    defaultItems[SessionStatus.PENDING] = session as any;
    setItemsByStatus(defaultItems)
     updateSearchSession();
  }, [])

  const handleDragEnd: DragDropContextProps['onDragEnd'] = async ({
    source,
    destination
  }) => {
    setItemsByStatus(current =>
      produce(current, draft => {
        // dropped outside the list
        if (!destination) {
          return
        }
        const [removed] = draft[source.droppableId as SessionStatus].splice(
          source.index,
          1
        )
        draft[destination.droppableId as SessionStatus].splice(
          destination.index,
          0,
          removed
        )
      })
    )

    await updateSearchSession();

    //TODO: try to use the following code since it is simple and easier to debug
    // setItemsByStatus((current:any) => {
    //   const sourceList = current?.[source.droppableId];
    //   const destList = current?.[destination?.droppableId as any]

    //   if (!sourceList || !destList) {
    //     return current
    //   }

    //   const [removed] = sourceList.splice(source.index, 1)
    //   destList.splice(destination?.index ?? destList.length, 0, removed)

    //   return { ...current }
    // })
  }

  const onClickAdd = async (itemToEdit: Roadmap[], sourceStatus: SessionStatus) => {
    const destStatus =
      sourceStatus === SessionStatus.PENDING ||
        sourceStatus === SessionStatus.REJECTED
        ? SessionStatus.APPROVED
        : SessionStatus.REJECTED

    setItemsByStatus(prevState => {
      const updatedItemsByStatus = { ...prevState }
      updatedItemsByStatus[sourceStatus] = [
        ...itemToEdit.filter((x: any) => x.selected === false)
      ]
      updatedItemsByStatus[destStatus] = [
        ...updatedItemsByStatus[destStatus],
        ...itemToEdit.filter((x: any) => x.selected === true)
      ]
      return updatedItemsByStatus
    })

    await updateSearchSession();

  }

  const setCheckBoxStatus = (status: SessionStatus, checked: boolean) => {
    setItemsByStatus(prevState => {
      const updatedItemsByStatus = { ...prevState }
      updatedItemsByStatus[status] = prevState[status].map(item => {
        return { ...item, selected: checked }
      })
      return updatedItemsByStatus
    })
  }

  const search = (status: SessionStatus, keyword: string) => {
    setItemsByStatus(prevState => {
      const updatedItemsByStatus = { ...prevState }
      updatedItemsByStatus[status] = prevState[status].filter(
        (session: Roadmap) =>
          session.roadmapId.includes(keyword) ||
          session.description.includes(keyword)
      )
      return updatedItemsByStatus
    })
  }

  const globalSearch = (searchTerm: string, statusFilter: SessionStatus) => {
    const data = filterItemGlobally(searchTerm, statusFilter, sessionItems)
    setItemsByStatus(data)
  }

  const  updateSearchSession = async () => {

    const newItems = JSON.parse(JSON.stringify(itemsByStatus));
    setSessionItems(newItems)
    //TODO: remove after testing
    localStorage.setItem('sessionItems',  JSON.stringify(newItems))

  }

  return (
    <>
      <SearchBox globalSearch={globalSearch} />
      <DragDropContext onDragEnd={handleDragEnd}>
        <SessionRoot>
          <SessionContent>
            {Object.values(SessionStatus).map(status => (
              <SessionCol
                setItemsByStatus={setCheckBoxStatus}
                key={status}
                status={status}
                items={itemsByStatus[status]}
                search={search}
                onClickAdd={() => onClickAdd(sessionItems[status], status)}
              />
            ))}
          </SessionContent>
        </SessionRoot>
      </DragDropContext>
    </>
  )
}

export default SessionMain
