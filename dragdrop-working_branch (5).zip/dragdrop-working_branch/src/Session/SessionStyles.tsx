import styled, { css } from 'styled-components'
import { Card, Checkbox, Typography } from 'antd'
import { colors } from '../shared/SharedUtils'

import { DroppableRootProps, StyledCardProps } from '../misc/Types'
export const SessionRoot = styled.div`
  min-height: 0;
  height: 100%;
  min-width: 800px;
  max-width: 1400px;
  margin: auto;
`
export const SessionContent = styled.div`
  height: 100%;
  padding: 0.1rem;
  display: flex;
  justify-content: space-around;
`
export const SessionColRoot = styled(Card)`
  user-select: none;
  background-color: ${colors.smsGreyBright};
  flex: 1;
  margin: 0.5rem;
  display: flex;
  flex-direction: column;
  // To force each flex item to have equal width
  // even if they have long texts with no spaces etc.
  min-width: 0;
  > .ant-card-body {
    overflow: hidden;
    height: 100%;
    background-color: ${colors.smsWhite};
  }
`

export const DroppableRoot = styled.div<DroppableRootProps>`
  height: 100%;
  overflow-y: auto;
  background-color: ${({ isDraggingOver }) =>
    isDraggingOver ? colors.smsSuccess :colors.smsGreyBright};
    background: ${colors.smsWhite}
`

export const StyledCard = styled(Card)<StyledCardProps>`
  margin: 0.5rem;
  padding: 0.5rem;
  background-color: ${({ $isDragging }) =>
    $isDragging ? colors.smsSuccess : colors.smsGreyBright};
    background: ${colors.smsGreyBright};
`
export const SessiontemCardTitle = styled(Typography.Title)`
  white-space: pre-wrap;
  // To make ellipsis of the title visible.
  // Without this margin, it can be go behind the "extra" component.
  // So, we give it a little space.
  background: ${colors.smsGreyBright};
`

export const CustomCheckbox = styled(Checkbox)`
  width: 25px;
  height: 25px;
`

export const SessionButton = styled.button<any>`
  ${(props: {colors:string}) => {
         return css`
          background-color: ${props.colors};
          color: ${colors.smsWhite};
          padding: 0.25em 1em;
        `
    
    }
  }}
`

export const SearchSelect = styled.select`
  font-size: 14px;
  padding: 4px ;
  border: 1px solid black;
  background-color: #fff;
  color: #333;

  &:focus {
    outline: none;
    border-color: #2e7d32;
  }
`;

export const CenteredDiv = styled.div`
display: flex;
justify-content: center;
align-items: center;

`;
