import { SessionStatus } from './Types'

const statuses = ['Approved', 'Rejected', 'Pending']

const firstNames = [
  'Emma',
  'Noah',
  'Olivia',
  'Liam',
  'Ava',
  'William',
  'Sophia',
  'Mason',
  'Isabella',
  'James',
  'Mia',
  'Benjamin',
  'Charlotte',
  'Jacob',
  'Amelia',
  'Michael',
  'Harper',
  'Ethan',
  'Evelyn',
  'Elijah',
  'Abigail',
  'Daniel',
  'Emily',
  'Logan',
  'Elizabeth',
  'Matthew',
  'Sofia',
  'Lucas',
  'Madison',
  'Jackson',
  'Avery',
  'David',
  'Ella',
  'Joseph',
  'Scarlett',
  'Samuel',
  'Grace',
  'Henry',
  'Chloe',
  'Owen',
  'Victoria',
  'Sebastian',
  'Riley',
  'Nicholas',
  'Aria',
  'Christopher',
  'Luna'
]

const lastNames = [
  'Smith',
  'Johnson',
  'Williams',
  'Brown',
  'Jones',
  'Miller',
  'Davis',
  'Garcia',
  'Rodriguez',
  'Martinez',
  'Hernandez',
  'Lopez',
  'Gonzalez',
  'Perez',
  'Taylor',
  'Anderson',
  'Wilson',
  'Jackson',
  'Lee',
  'Lewis',
  'Hall',
  'Allen',
  'Young',
  'King',
  'Wright',
  'Scott',
  'Green',
  'Baker',
  'Adams',
  'Nelson',
  'Carter',
  'Mitchell',
  'Perez',
  'Roberts',
  'Turner',
  'Phillips',
  'Campbell',
  'Parker',
  'Evans',
  'Edwards',
  'Collins',
  'Stewart',
  'Sanchez',
  'Morris',
  'Rogers',
  'Reed',
  'Cook',
  'Bailey',
  'Rivera',
  'Cooper',
  'Morgan',
  'Peterson',
  'Ramos',
  'Kim'
]

// Generate a random person name
function generateRandomPerson () {
  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)]
  const lastName = lastNames[Math.floor(Math.random() * lastNames.length)]
  return `${firstName} ${lastName}`
}
const roadmapNames: string[] = [
  'Innovation Roadmap',
  'Growth Roadmap',
  'Digital Transformation Roadmap',
  'Customer Experience Roadmap',
  'Talent Development Roadmap',
  'Operational Efficiency Roadmap',
  'Sustainability Roadmap',
  'Product Development Roadmap',
  'Marketing Roadmap',
  'Sales Roadmap'
]

const roadmapDescriptions: string[] = [
  'A roadmap for exploring and implementing new ideas and technologies to stay ahead of the competition.',
  'A roadmap for achieving sustainable growth by expanding market share, increasing revenue, and improving profitability.',
  'A roadmap for transforming business processes and operations using digital technologies to gain competitive advantage.',
  'A roadmap for creating a superior customer experience by understanding their needs and expectations and delivering exceptional service.',
  'A roadmap for developing and retaining employees through training, mentoring, and career development programs.',
  'A roadmap for improving business efficiency and productivity by streamlining processes, reducing costs, and eliminating waste.',
  'A roadmap for reducing environmental impact and promoting social responsibility through sustainable business practices.',
  'A roadmap for developing new products and services that meet the changing needs and preferences of customers.',
  'A roadmap for promoting a brand, product, or service through targeted communication and advertising strategies.',
  'A roadmap for achieving sales targets by identifying new market opportunities, building strong customer relationships, and enhancing sales performance.'
]


const phaseDescriptions = [
  "plan and research the project to identify the requirements, risks, and opportunities.",
  "design the solution and create the necessary documentation, diagrams, and mockups.",
  "develop and test the solution, including coding, unit testing, integration testing, and user acceptance testing.",
  " deploy the solution to the production environment and perform final testing and verification.",
  "provide ongoing maintenance and support to ensure the solution remains operational and effective."
];



// Generate a random boolean value
function generateBoolean () {
  return Math.random() < 0.5
}

// Generate a random choice value from a list of options
function generateChoice (options: any) {
  return options[Math.floor(Math.random() * options.length)]
}

// Generate a random string value with a given length
function generateString (length: any) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = ''
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

// Generate a random number between min and max (inclusive)
function generateNumber (min: any, max: any) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Generate a random RoadmapParameter object
function generateRoadmapParameter () {
  const type = generateChoice(['boolean', 'choice', 'string', 'number'])
  let value
  switch (type) {
    case 'boolean':
      value = generateBoolean()
      break
    case 'choice':
      value = generateChoice(['option1', 'option2', 'option3'])
      break
    case 'string':
      value = generateString(10)
      break
    case 'number':
      value = generateNumber(1, 10)
      break
  }
  return {
    name: generateString(5),
    type: type,
    value: value.toString()
  }
}

// Generate a random RoadmapPhase object
function generateRoadmapPhase (phaseId: any) {
  return {
    phaseId: phaseId,
    versionId: generateNumber(1, 5),
    environment: generateChoice([
      'sandbox',
      'development',
      'testing',
      'production'
    ]),
    verifiedBy: generateString(8),
    description: generateChoice(phaseDescriptions),
    criticalMethod: generateString(8),
    keywords: [generateString(5), generateString(5), generateString(5)],
    parameters: [
      generateRoadmapParameter(),
      generateRoadmapParameter(),
      generateRoadmapParameter()
    ]
  }
}

// Generate a random RoadmapOverride object
function generateRoadmapOverride () {
  return {}
}

// Generate a random Roadmap object
const generateSession = () => {
  const phases = [
    generateRoadmapPhase(1),
    generateRoadmapPhase(2),
    generateRoadmapPhase(3)
  ]
  return {
    roadmapId: generateString(8),
    roadmapName: roadmapNames[
      Math.floor(Math.random() * roadmapNames.length)
    ] as string,
    description: roadmapDescriptions[
      Math.floor(Math.random() * roadmapDescriptions.length)
    ] as string,
    versionId: generateString(4),
    environment: generateChoice([
      'sandbox',
      'development',
      'testing',
      'production'
    ]),
    verifiedBy: generateRandomPerson(),
    keywords: [generateString(7), generateString(7)],
    parameters: [generateRoadmapParameter(), generateRoadmapParameter()],
    phases: phases,
    overrides: [generateRoadmapOverride(), generateRoadmapOverride()],
    pipeline: {},
    status: statuses[
      Math.floor(Math.random() * statuses.length)
    ] as SessionStatus,
    selected:false
  }
}
export const session: any = []

for (let index = 0; index < 20; index++) {
  session.push(generateSession())
}
