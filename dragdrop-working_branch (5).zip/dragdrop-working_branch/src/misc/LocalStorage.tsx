
export class LocalStorageCRUD {
  private static storageKey = 'roadmap_sessions';

  // Create a new any and store it in Local Storage
  public static create(session: any): void {
    let sessions = this.read();
    session.id = Date.now().toString();
    sessions.push(session);
    localStorage.setItem(this.storageKey, JSON.stringify(sessions));
  }

  // Read all anys from Local Storage
  public static read(): any[] {
    let sessions = localStorage.getItem(this.storageKey);
    if (!sessions) {
      return [];
    }
    return JSON.parse(sessions);
  }

  // Update an existing any in Local Storage
  public static update(session: any): void {
    let sessions = this.read();
    let index = sessions.findIndex((s) => s.id === session.id);
    if (index !== -1) {
      sessions[index] = session;
      localStorage.setItem(this.storageKey, JSON.stringify(sessions));
    }
  }

  // Delete a any from Local Storage
  public static delete(roadmapId: string): void {
    let sessions = this.read();
    let index = sessions.findIndex((s) => s.id === roadmapId);
    if (index !== -1) {
      sessions.splice(index, 1);
      localStorage.setItem(this.storageKey, JSON.stringify(sessions));
    }
  }

  // Delete a any from Local Storage
  public static remove(): void {
    localStorage.removeItem(this.storageKey);
  }
}
