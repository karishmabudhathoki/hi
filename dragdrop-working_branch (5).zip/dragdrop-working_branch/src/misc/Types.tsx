export interface SessionItem {
  id: string;
  title: string;
  description: string;
}

export enum SessionStatus {
  PENDING = 'PENDING',
  REJECTED = 'REJECTED',
  APPROVED = 'APPROVED',
}

export type SessionColProps = {
  items: any[];
  status: SessionStatus;
  onClickAdd?: VoidFunction;
  setItemsByStatus: any;
  search?: any;
};

export interface DroppableRootProps {
  isDraggingOver: boolean;
}

//  This defines an interface called RoadmapSession with the specified properties and their data types. We can then use the interface to type
export interface Session {
  sessionId: string;
  missionId: string;
  requestId: string;
  status?: SessionStatus;
  sessionPlan: Array<SessionPlan>;
  selected: Boolean;
}
export interface SessionPlan {
  phaseId: string;
  serviceId: string;
  versionNo: string;
  serviceName: string;
  status?: SessionStatus;
  ioSpec: string;
}
export interface RoadmapSession {
  id: string;
  status: string;
  description: string;
  startDate: Date;
  endDate: Date;
  createdBy: string;
  checked: boolean;
  name: string;
  workflows: Workflow[];
}

//This defines an interface called Workflow with the specified properties and their data types. We can then use the interface to type check objects that represent workflows.
export interface Workflow {
  workflowId: number;
  name: string;
  step: string;
  details: string;
  output: string;
  status: string;
  checked: boolean;
}

export type Color = 'warning' | 'info' | 'success' | 'danger';

//usage : const AlertIcon = ({ className, color, ...props }: IProps) => { ... }
export interface IProps {
  color: Color;
}

export interface WorkflowProps {
  updateSession: any;
  workflows: any[];
  handleCheckbox: any;
}



export interface StyledCardProps {
  $isDragging: boolean;
}

export interface SessionItemCardProps {
  item: Roadmap;
  isDragging: boolean;
  status: SessionStatus;
}


export interface RoadmapParameter {
  name: string;
  type: "boolean" | "choice" | "string" | "number";
  value: string;
}

export interface RoadmapPhase {
  phaseId: number;
  versionId: number;
  environment: "sandbox" | "development" | "testing" | "production";
  verifiedBy: string;
  description: string;
  criticalMethod: string;
  keywords: string[];
  parameters: RoadmapParameter[];
}

export interface RoadmapOverride { }

export interface Roadmap {
  roadmapId: string;
  roadmapName: string;
  versionId: string;
  environment: "sandbox" | "development" | "testing" | "production";
  verifiedBy: string;
  description: string;
  keywords: string[];
  parameters: RoadmapParameter[];
  phases: RoadmapPhase[];
  overrides: RoadmapOverride[];
  pipeline: unknown; 
  status?: SessionStatus;
  selected: Boolean;
  // pipeline object not specified in the schema
}

export type SessionData = Record<SessionStatus, any[]>
