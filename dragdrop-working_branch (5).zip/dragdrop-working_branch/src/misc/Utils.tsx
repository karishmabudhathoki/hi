import { colors } from "../shared/SharedUtils";
import { Roadmap, SessionData, SessionStatus } from "./Types";

export const getStatusButton =(status: string) => {
    switch (status) {
      case SessionStatus.PENDING:
        return { text: 'Approve Selected', buttonColor: colors.smsPrimary};
      case SessionStatus.REJECTED:
        return { text: 'Approve Selected', buttonColor: colors.smsWarning };
      case SessionStatus.APPROVED:
        return { text: 'Reject Selected', buttonColor: colors.smsDanger };
    }
  }

  export const filterItemGlobally = (
    searchTerm: string,
    statusFilter: SessionStatus,
    sessions :SessionData
  ) => {
    const filteredItems = Object.entries(sessions).reduce(
      (acc: any, [status, items]): any => {
        if (
          (!statusFilter || status === statusFilter) &&
          items.some(
            (item: Roadmap): any =>
              item.description.toLowerCase().includes(searchTerm) ||
              item.verifiedBy.toLowerCase().includes(searchTerm) ||
              item.versionId.toLowerCase().includes(searchTerm) ||
              item.roadmapName.toLowerCase().includes(searchTerm)
          )
        ) {
          acc[status] = items.filter(
            (item: Roadmap) =>
              item.description.toLowerCase().includes(searchTerm) ||
              item.verifiedBy.toLowerCase().includes(searchTerm) ||
              item.versionId.toLowerCase().includes(searchTerm) ||
              item.roadmapName.toLowerCase().includes(searchTerm)
          )
        }
        return acc
      },
      { PENDING: [], APPROVED: [], REJECTED: [] }
    )
    return filteredItems
  }
