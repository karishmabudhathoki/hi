import { Avatar, Button, Card, Layout } from 'antd';
import Meta from 'antd/lib/card/Meta';

function Phase() {

    return (
        <Layout>
            <Card
                style={{ width: 1000 }}
                cover={
                    <img
                        alt="example"
                        src="https://sparxsystems.com/enterprise_architect_user_guide/15.2/images/business-process-diagram-with-lanes-8364.png"
                    />
                }
                actions={[<Button>REJECT</Button>]}
            >
                <Meta
                    avatar={<Avatar src="https://joeschmoe.io/api/v1/random" />}
                    title="PHASE ITEM IN PROGRESS"
                    description="This is the description"
                />
            </Card>
        </Layout>
    );
}

export default Phase;
