import { useEffect, useState } from 'react'
import { CenteredDiv, SearchSelect } from '../Session/SessionStyles'

export const SearchBox = ({
 globalSearch
}: any) => {
  const [searchTermItem, setSearchTerm] = useState('' as string)
  const [statusFilter, setStatusFilter] = useState('' as string)
 
  useEffect(() => {
  
  }, [])

  const handleSearch = () => {
    const searchTerm = searchTermItem.toLowerCase();
    globalSearch(searchTerm, statusFilter)
   }

  return (
    <CenteredDiv>
      <input
        type='text'
        placeholder='Search'
        value={searchTermItem}
        onChange={e => setSearchTerm(e.target.value)}
      />
      <SearchSelect
        className="dropdown"
        value={statusFilter}
        onChange={e => setStatusFilter(e.target.value)}
      >
        <option value=''>All</option>
        <option value='PENDING'>Pending</option>
        <option value='APPROVED'>Approved</option>
        <option value='REJECTED'>Rejected</option>
      </SearchSelect>
      <button onClick={handleSearch}>Search</button>
    </CenteredDiv>
  )
}

export default SearchBox
